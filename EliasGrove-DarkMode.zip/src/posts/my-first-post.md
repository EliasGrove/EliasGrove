---
title: First Post!
layout: layout.njk
---

# 📝 First Blog Post

This is a test post for my author website.  
I’ll be writing about my journey, fiction, creativity, and thoughts on storytelling.
